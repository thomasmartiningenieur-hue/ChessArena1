package com.chessarena.service;

import com.chessarena.model.ChessGame;
import com.chessarena.model.Player;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * File d'attente simple pour le matchmaking.
 * Des ameliorations possibles : appariement par rating (+/- une plage), timeout, etc.
 */
@Service
@RequiredArgsConstructor
public class MatchmakingService {

    private final ChessGameService chessGameService;

    private final ConcurrentLinkedQueue<Player> waitingQueue = new ConcurrentLinkedQueue<>();

    /**
     * Ajoute un joueur a la file d'attente. Si un adversaire est disponible,
     * cree immediatement une partie et retourne son id ; sinon retourne null
     * (le joueur reste en attente et sera notifie via WebSocket a l'appariement).
     */
    public synchronized ChessGame joinQueue(Player player) {
        Player opponent = waitingQueue.poll();

        if (opponent == null || opponent.getId().equals(player.getId())) {
            if (opponent != null) {
                waitingQueue.offer(opponent);
            }
            waitingQueue.offer(player);
            return null;
        }

        // Couleurs attribuees arbitrairement (premier arrive = blancs)
        return chessGameService.createGame(opponent, player);
    }

    public void leaveQueue(Player player) {
        waitingQueue.removeIf(p -> p.getId().equals(player.getId()));
    }

    public int queueSize() {
        return waitingQueue.size();
    }
}
