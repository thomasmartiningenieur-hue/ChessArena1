package com.chessarena.dto;

import com.chessarena.model.ChessGame;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GameResponse {
    private Long id;
    private String fen;
    private ChessGame.Status status;
    private ChessGame.Result result;
    private String whitePlayerUsername;
    private String blackPlayerUsername;

    public static GameResponse fromEntity(ChessGame game) {
        return GameResponse.builder()
                .id(game.getId())
                .fen(game.getFen())
                .status(game.getStatus())
                .result(game.getResult())
                .whitePlayerUsername(game.getWhitePlayer() != null ? game.getWhitePlayer().getUsername() : null)
                .blackPlayerUsername(game.getBlackPlayer() != null ? game.getBlackPlayer().getUsername() : null)
                .build();
    }
}
