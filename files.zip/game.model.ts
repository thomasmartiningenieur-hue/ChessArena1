export type GameStatus = 'WAITING' | 'IN_PROGRESS' | 'FINISHED' | 'ABANDONED';
export type GameResult = 'WHITE_WINS' | 'BLACK_WINS' | 'DRAW' | 'ONGOING';

export interface ChessGame {
  id: number;
  fen: string;
  status: GameStatus;
  result: GameResult;
  whitePlayerUsername: string | null;
  blackPlayerUsername: string | null;
}

export interface GameUpdateEvent {
  gameId: number;
  fen: string;
  status: GameStatus;
  result: GameResult;
  lastMoveSan: string | null;
}
