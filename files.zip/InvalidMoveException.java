package com.chessarena.exception;

public class InvalidMoveException extends RuntimeException {
    public InvalidMoveException(String uci) {
        super("Coup invalide : " + uci);
    }
}
