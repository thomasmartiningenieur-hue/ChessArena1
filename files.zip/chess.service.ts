import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { ChessGame } from '../models/game.model';

@Injectable({ providedIn: 'root' })
export class ChessService {
  constructor(private http: HttpClient) {}

  getGame(id: number): Observable<ChessGame> {
    return this.http.get<ChessGame>(`${environment.apiUrl}/games/${id}`);
  }

  playMove(gameId: number, uci: string): Observable<ChessGame> {
    return this.http.post<ChessGame>(`${environment.apiUrl}/games/${gameId}/moves`, { uci });
  }

  abandonGame(gameId: number): Observable<void> {
    return this.http.post<void>(`${environment.apiUrl}/games/${gameId}/abandon`, {});
  }

  getBestMove(gameId: number, depth?: number): Observable<string> {
    const params = depth ? `?depth=${depth}` : '';
    return this.http.get<string>(`${environment.apiUrl}/games/${gameId}/best-move${params}`);
  }

  joinMatchmaking(): Observable<ChessGame> {
    return this.http.post<ChessGame>(`${environment.apiUrl}/matchmaking/join`, {});
  }

  leaveMatchmaking(): Observable<void> {
    return this.http.post<void>(`${environment.apiUrl}/matchmaking/leave`, {});
  }
}
