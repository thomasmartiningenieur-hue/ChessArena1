import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ChessGame } from '../../models/game.model';

@Component({
  selector: 'app-game-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="game-list">
      @for (game of games; track game.id) {
        <a [routerLink]="['/game', game.id]" class="game-card">
          <span>{{ game.whitePlayerUsername || 'Blancs' }} vs {{ game.blackPlayerUsername || 'Noirs' }}</span>
          <span class="status">{{ game.status }}</span>
        </a>
      }
    </div>
  `,
  styles: [`
    .game-list { display: flex; flex-direction: column; gap: 0.5rem; }
    .game-card {
      display: flex;
      justify-content: space-between;
      padding: 0.75rem 1rem;
      background: #16161f;
      color: #f0f0f0;
      text-decoration: none;
      border-radius: 6px;
    }
    .status { opacity: 0.7; font-size: 0.85rem; }
  `]
})
export class GameListComponent {
  @Input() games: ChessGame[] = [];
}
