package com.chessarena.service;

import com.chessarena.exception.GameNotFoundException;
import com.chessarena.exception.InvalidMoveException;
import com.chessarena.model.ChessGame;
import com.chessarena.model.Move;
import com.chessarena.model.Player;
import com.chessarena.repository.ChessGameRepository;
import com.chessarena.repository.MoveRepository;
import com.github.bhlangonijr.chesslib.Board;
import com.github.bhlangonijr.chesslib.move.MoveGenerator;
import com.github.bhlangonijr.chesslib.move.MoveList;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ChessGameService {

    private final ChessGameRepository chessGameRepository;
    private final MoveRepository moveRepository;

    @Transactional
    public ChessGame createGame(Player white, Player black) {
        ChessGame game = ChessGame.builder()
                .whitePlayer(white)
                .blackPlayer(black)
                .status(ChessGame.Status.IN_PROGRESS)
                .build();
        return chessGameRepository.save(game);
    }

    public ChessGame getById(Long id) {
        return chessGameRepository.findById(id)
                .orElseThrow(() -> new GameNotFoundException(id));
    }

    /**
     * Joue un coup au format UCI (ex: "e2e4"), valide sa legalite via chesslib,
     * met a jour le FEN et l'historique, et detecte fin de partie (mat/pat).
     */
    @Transactional
    public ChessGame playMove(Long gameId, String uci) {
        ChessGame game = getById(gameId);

        if (game.getStatus() != ChessGame.Status.IN_PROGRESS) {
            throw new InvalidMoveException("La partie n'est pas en cours");
        }

        Board board = new Board();
        board.loadFromFen(game.getFen());

        com.github.bhlangonijr.chesslib.move.Move chessLibMove;
        try {
            chessLibMove = new com.github.bhlangonijr.chesslib.move.Move(uci, board.getSideToMove());
        } catch (Exception e) {
            throw new InvalidMoveException(uci);
        }

        MoveList legalMoves = MoveGenerator.generateLegalMoves(board);
        boolean isLegal = legalMoves.stream().anyMatch(m -> m.toString().equalsIgnoreCase(uci));

        if (!isLegal) {
            throw new InvalidMoveException(uci);
        }

        String sanNotation = com.github.bhlangonijr.chesslib.move.MoveConversion.toSan(board, chessLibMove);
        board.doMove(chessLibMove);

        int moveNumber = game.getMoves().size() + 1;
        Move move = Move.builder()
                .game(game)
                .moveNumber(moveNumber)
                .san(sanNotation)
                .uci(uci)
                .fenAfter(board.getFen())
                .build();

        moveRepository.save(move);
        game.getMoves().add(move);
        game.setFen(board.getFen());

        if (board.isMated()) {
            game.setStatus(ChessGame.Status.FINISHED);
            game.setResult(board.getSideToMove().value().equals("WHITE")
                    ? ChessGame.Result.BLACK_WINS
                    : ChessGame.Result.WHITE_WINS);
        } else if (board.isDraw() || board.isStaleMate()) {
            game.setStatus(ChessGame.Status.FINISHED);
            game.setResult(ChessGame.Result.DRAW);
        }

        return chessGameRepository.save(game);
    }

    @Transactional
    public void abandonGame(Long gameId) {
        ChessGame game = getById(gameId);
        game.setStatus(ChessGame.Status.ABANDONED);
        chessGameRepository.save(game);
    }
}
