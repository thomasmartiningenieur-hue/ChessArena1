package com.chessarena.websocket;

import com.chessarena.model.ChessGame;
import com.chessarena.service.ChessGameService;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

/**
 * Gere les echanges temps reel pendant une partie :
 * - le client envoie un coup sur /app/games/{gameId}/move
 * - le serveur diffuse la mise a jour a tous les abonnes de /topic/games/{gameId}
 */
@Controller
@RequiredArgsConstructor
public class ChessSocketController {

    private final ChessGameService chessGameService;
    private final SimpMessagingTemplate messagingTemplate;

    @MessageMapping("/games/{gameId}/move")
    public void handleMove(@DestinationVariable Long gameId, WebSocketEvents.MoveEvent event) {
        ChessGame game = chessGameService.playMove(gameId, event.getUci());

        String lastMoveSan = game.getMoves().isEmpty()
                ? null
                : game.getMoves().get(game.getMoves().size() - 1).getSan();

        WebSocketEvents.GameUpdateEvent update = new WebSocketEvents.GameUpdateEvent(
                game.getId(),
                game.getFen(),
                game.getStatus().name(),
                game.getResult().name(),
                lastMoveSan
        );

        messagingTemplate.convertAndSend("/topic/games/" + gameId, update);
    }

    @MessageMapping("/games/{gameId}/chat")
    public void handleChat(@DestinationVariable Long gameId, WebSocketEvents.ChatEvent event) {
        messagingTemplate.convertAndSend("/topic/games/" + gameId + "/chat", event);
    }
}
