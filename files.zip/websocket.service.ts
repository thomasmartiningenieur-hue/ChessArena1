import { Injectable } from '@angular/core';
import { Client, IMessage } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { GameUpdateEvent } from '../models/game.model';

@Injectable({ providedIn: 'root' })
export class WebsocketService {
  private client: Client | null = null;

  connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.client = new Client({
        webSocketFactory: () => new SockJS(environment.wsUrl),
        reconnectDelay: 5000,
        onConnect: () => resolve(),
        onStompError: (frame) => reject(frame)
      });
      this.client.activate();
    });
  }

  disconnect(): void {
    this.client?.deactivate();
  }

  watchGame(gameId: number): Observable<GameUpdateEvent> {
    return new Observable((observer) => {
      const subscription = this.client?.subscribe(`/topic/games/${gameId}`, (message: IMessage) => {
        observer.next(JSON.parse(message.body) as GameUpdateEvent);
      });
      return () => subscription?.unsubscribe();
    });
  }

  sendMove(gameId: number, uci: string, username: string): void {
    this.client?.publish({
      destination: `/app/games/${gameId}/move`,
      body: JSON.stringify({ gameId, uci, username })
    });
  }
}
