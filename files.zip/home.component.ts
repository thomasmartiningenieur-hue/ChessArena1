import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ChessService } from '../../services/chess.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="home">
      <h1>Bienvenue sur ChessArena</h1>
      <p>Affrontez d'autres joueurs en temps reel ou analysez vos parties avec Stockfish.</p>
      @if (auth.isAuthenticated()) {
        <button (click)="findMatch()" [disabled]="searching">
          {{ searching ? 'Recherche en cours...' : 'Trouver une partie' }}
        </button>
      } @else {
        <p>Connectez-vous pour commencer a jouer.</p>
      }
    </div>
  `,
  styles: [`
    .home { max-width: 600px; margin: 3rem auto; text-align: center; }
    button { padding: 0.8rem 1.5rem; font-size: 1rem; cursor: pointer; margin-top: 1rem; }
  `]
})
export class HomeComponent implements OnInit {
  searching = false;

  constructor(
    private chessService: ChessService,
    public auth: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {}

  findMatch(): void {
    this.searching = true;
    this.chessService.joinMatchmaking().subscribe({
      next: (game) => {
        this.searching = false;
        if (game?.id) {
          this.router.navigate(['/game', game.id]);
        }
      },
      error: () => (this.searching = false)
    });
  }
}
