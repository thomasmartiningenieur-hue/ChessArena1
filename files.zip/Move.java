package com.chessarena.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Entity
@Table(name = "moves")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Move {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "game_id", nullable = false)
    private ChessGame game;

    @Column(nullable = false)
    private Integer moveNumber;

    // Notation SAN, ex: "Nf3", "e4", "O-O"
    @Column(nullable = false, length = 16)
    private String san;

    // Notation UCI, ex: "e2e4"
    @Column(nullable = false, length = 8)
    private String uci;

    @Column(nullable = false, length = 100)
    private String fenAfter;

    @Builder.Default
    @Column(nullable = false)
    private Instant playedAt = Instant.now();
}
