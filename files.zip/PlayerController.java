package com.chessarena.controller;

import com.chessarena.dto.PlayerResponse;
import com.chessarena.service.PlayerService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/players")
@RequiredArgsConstructor
@Tag(name = "Joueurs", description = "Profils et classement des joueurs")
public class PlayerController {

    private final PlayerService playerService;

    @GetMapping("/{id}")
    public ResponseEntity<PlayerResponse> getPlayer(@PathVariable Long id) {
        return ResponseEntity.ok(PlayerResponse.fromEntity(playerService.getById(id)));
    }

    @GetMapping("/username/{username}")
    public ResponseEntity<PlayerResponse> getByUsername(@PathVariable String username) {
        return ResponseEntity.ok(PlayerResponse.fromEntity(playerService.getByUsername(username)));
    }

    @GetMapping("/leaderboard")
    public ResponseEntity<List<PlayerResponse>> getLeaderboard() {
        List<PlayerResponse> leaderboard = playerService.getLeaderboard().stream()
                .map(PlayerResponse::fromEntity)
                .toList();
        return ResponseEntity.ok(leaderboard);
    }
}
