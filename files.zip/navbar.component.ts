import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <nav class="navbar">
      <a routerLink="/" class="brand">ChessArena</a>
      <div class="links">
        @if (auth.currentUsername()) {
          <span>{{ auth.currentUsername() }}</span>
          <button (click)="auth.logout()">Deconnexion</button>
        } @else {
          <a routerLink="/login">Connexion</a>
          <a routerLink="/register">Inscription</a>
        }
      </div>
    </nav>
  `,
  styles: [`
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 2rem;
      background-color: #16161f;
    }
    .brand { font-weight: bold; font-size: 1.3rem; color: #f0f0f0; text-decoration: none; }
    .links { display: flex; gap: 1rem; align-items: center; }
    a { color: #f0f0f0; text-decoration: none; }
    button { cursor: pointer; }
  `]
})
export class NavbarComponent {
  constructor(public auth: AuthService) {}
}
