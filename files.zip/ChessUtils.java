package com.chessarena.util;

/**
 * Utilitaires divers autour de la notation d'echecs.
 */
public final class ChessUtils {

    public static final String STARTING_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

    private ChessUtils() {
    }

    /** Verifie qu'une chaine ressemble a un coup UCI valide (ex: e2e4, e7e8q). */
    public static boolean isValidUciFormat(String uci) {
        if (uci == null) {
            return false;
        }
        return uci.matches("^[a-h][1-8][a-h][1-8][qrbn]?$");
    }

    /** Extrait la couleur au trait a partir d'un FEN ("w" ou "b"). */
    public static String sideToMove(String fen) {
        if (fen == null || fen.isBlank()) {
            return "w";
        }
        String[] parts = fen.trim().split("\\s+");
        return parts.length > 1 ? parts[1] : "w";
    }
}
