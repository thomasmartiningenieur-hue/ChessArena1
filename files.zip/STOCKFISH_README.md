Le binaire Stockfish n'est PAS versionne ici.
En local : installez-le via votre gestionnaire de paquets (ex: `sudo apt install stockfish`
ou `brew install stockfish`) puis definissez la variable d'environnement STOCKFISH_PATH.
En production/Docker : Stockfish est installe automatiquement dans le Dockerfile du backend.
