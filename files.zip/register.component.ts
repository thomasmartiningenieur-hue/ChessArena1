import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="form-container">
      <h2>Inscription</h2>
      <form (ngSubmit)="onSubmit()">
        <input [(ngModel)]="username" name="username" placeholder="Nom d'utilisateur" required>
        <input [(ngModel)]="email" name="email" type="email" placeholder="Email" required>
        <input [(ngModel)]="password" name="password" type="password" placeholder="Mot de passe" required>
        <button type="submit">S'inscrire</button>
      </form>
      @if (error) {
        <p class="error">{{ error }}</p>
      }
    </div>
  `,
  styles: [`
    .form-container { max-width: 320px; margin: 4rem auto; display: flex; flex-direction: column; gap: 1rem; }
    form { display: flex; flex-direction: column; gap: 0.75rem; }
    input { padding: 0.6rem; border-radius: 4px; border: 1px solid #444; }
    button { padding: 0.6rem; cursor: pointer; }
    .error { color: #ff6b6b; }
  `]
})
export class RegisterComponent {
  username = '';
  email = '';
  password = '';
  error = '';

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit(): void {
    this.authService.register({ username: this.username, email: this.email, password: this.password }).subscribe({
      next: () => this.router.navigate(['/']),
      error: (err) => (this.error = err?.error?.message || "Erreur lors de l'inscription")
    });
  }
}
