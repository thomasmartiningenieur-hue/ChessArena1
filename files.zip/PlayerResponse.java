package com.chessarena.dto;

import com.chessarena.model.Player;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PlayerResponse {
    private Long id;
    private String username;
    private Integer rating;
    private Integer gamesPlayed;
    private Integer gamesWon;

    public static PlayerResponse fromEntity(Player player) {
        return PlayerResponse.builder()
                .id(player.getId())
                .username(player.getUsername())
                .rating(player.getRating())
                .gamesPlayed(player.getGamesPlayed())
                .gamesWon(player.getGamesWon())
                .build();
    }
}
