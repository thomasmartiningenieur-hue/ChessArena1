# ChessArena

Plateforme web d'echecs en temps reel, developpee en solo.

## Stack technique

- **Backend** : Java 17, Spring Boot 3, Spring Security (JWT), Spring Data JPA, WebSocket (STOMP), PostgreSQL
- **Frontend** : Angular 18 (standalone components), chess.js, STOMP.js
- **Moteur d'analyse** : Stockfish (via protocole UCI)
- **Documentation API** : Swagger / OpenAPI
- **Deploiement** : Docker Compose (backend, frontend, PostgreSQL)

## Lancer le projet

### Avec Docker (recommande)

```bash
docker compose up --build
```

- Frontend : http://localhost
- Backend API : http://localhost:8080/api
- Swagger UI : http://localhost:8080/swagger-ui.html

### En local (developpement)

**Backend**
```bash
cd backend
mvn spring-boot:run
```
Necessite PostgreSQL local et Stockfish installe (`sudo apt install stockfish` ou equivalent),
avec la variable d'environnement `STOCKFISH_PATH` pointant vers le binaire si besoin.

**Frontend**
```bash
cd frontend
npm install
npm start
```
Disponible sur http://localhost:4200

## Architecture

```
ChessArena/
├── backend/     Spring Boot (API REST + WebSocket + Stockfish)
└── frontend/    Angular (SPA)
```

Voir le detail des dossiers dans chaque sous-projet.

## Fonctionnalites

- Inscription / connexion (JWT)
- Matchmaking simple (file d'attente)
- Parties en temps reel via WebSocket (STOMP)
- Validation des coups et detection de fin de partie (echec et mat, pat) via la librairie `chesslib`
- Analyse de position et meilleur coup via Stockfish
- Documentation API interactive (Swagger)

## Licence

MIT — voir [LICENSE](./LICENSE)
