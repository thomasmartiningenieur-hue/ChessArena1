package com.chessarena.controller;

import com.chessarena.dto.GameResponse;
import com.chessarena.model.ChessGame;
import com.chessarena.model.Player;
import com.chessarena.service.MatchmakingService;
import com.chessarena.service.PlayerService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/matchmaking")
@RequiredArgsConstructor
@Tag(name = "Matchmaking", description = "Mise en relation des joueurs")
public class MatchmakingController {

    private final MatchmakingService matchmakingService;
    private final PlayerService playerService;

    @PostMapping("/join")
    public ResponseEntity<GameResponse> joinQueue(Authentication authentication) {
        Player player = playerService.getByUsername(authentication.getName());
        ChessGame game = matchmakingService.joinQueue(player);
        return game != null
                ? ResponseEntity.ok(GameResponse.fromEntity(game))
                : ResponseEntity.accepted().build();
    }

    @PostMapping("/leave")
    public ResponseEntity<Void> leaveQueue(Authentication authentication) {
        Player player = playerService.getByUsername(authentication.getName());
        matchmakingService.leaveQueue(player);
        return ResponseEntity.noContent().build();
    }
}
