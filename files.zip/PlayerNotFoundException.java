package com.chessarena.exception;

public class PlayerNotFoundException extends RuntimeException {
    public PlayerNotFoundException(String identifier) {
        super("Joueur introuvable : " + identifier);
    }
}
