export interface Player {
  id: number;
  username: string;
  rating: number;
  gamesPlayed: number;
  gamesWon: number;
}
