package com.chessarena.service;

import com.chessarena.exception.PlayerNotFoundException;
import com.chessarena.model.Player;
import com.chessarena.repository.PlayerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PlayerService {

    private final PlayerRepository playerRepository;

    public Player getById(Long id) {
        return playerRepository.findById(id)
                .orElseThrow(() -> new PlayerNotFoundException(String.valueOf(id)));
    }

    public Player getByUsername(String username) {
        return playerRepository.findByUsername(username)
                .orElseThrow(() -> new PlayerNotFoundException(username));
    }

    public List<Player> getLeaderboard() {
        return playerRepository.findAll().stream()
                .sorted((a, b) -> b.getRating() - a.getRating())
                .limit(50)
                .toList();
    }
}
