package com.chessarena.service;

import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;

/**
 * Service d'integration du moteur Stockfish via le protocole UCI.
 * Chaque appel demarre un processus Stockfish dedie, l'interroge, puis le ferme.
 * Pour un usage plus intensif, envisager un pool de processus reutilisables.
 */
@Slf4j
@Service
public class StockfishService {

    @Value("${stockfish.path}")
    private String stockfishPath;

    @Value("${stockfish.default-depth:15}")
    private int defaultDepth;

    /**
     * Demande a Stockfish le meilleur coup pour une position FEN donnee.
     *
     * @param fen   position au format FEN
     * @param depth profondeur de recherche (facultatif, utilise la valeur par defaut sinon)
     * @return le meilleur coup au format UCI (ex: "e2e4"), ou null si indisponible
     */
    public String getBestMove(String fen, Integer depth) {
        int searchDepth = depth != null ? depth : defaultDepth;
        Process process = null;

        try {
            process = new ProcessBuilder(stockfishPath).redirectErrorStream(true).start();

            try (Writer writer = new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8);
                 BufferedReader reader = new BufferedReader(
                         new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {

                send(writer, "uci");
                waitFor(reader, "uciok");

                send(writer, "isready");
                waitFor(reader, "readyok");

                send(writer, "position fen " + fen);
                send(writer, "go depth " + searchDepth);

                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith("bestmove")) {
                        String[] parts = line.split("\\s+");
                        return parts.length > 1 ? parts[1] : null;
                    }
                }
            }
        } catch (IOException e) {
            log.error("Erreur lors de la communication avec Stockfish", e);
        } finally {
            if (process != null) {
                process.destroy();
            }
        }
        return null;
    }

    /**
     * Evalue une position (score en centipawns du point de vue du trait).
     */
    public Integer evaluatePosition(String fen, Integer depth) {
        int searchDepth = depth != null ? depth : defaultDepth;
        Process process = null;
        Integer lastScore = null;

        try {
            process = new ProcessBuilder(stockfishPath).redirectErrorStream(true).start();

            try (Writer writer = new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8);
                 BufferedReader reader = new BufferedReader(
                         new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {

                send(writer, "uci");
                waitFor(reader, "uciok");
                send(writer, "isready");
                waitFor(reader, "readyok");
                send(writer, "position fen " + fen);
                send(writer, "go depth " + searchDepth);

                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.contains("score cp")) {
                        String[] parts = line.split("\\s+");
                        for (int i = 0; i < parts.length; i++) {
                            if (parts[i].equals("cp") && i + 1 < parts.length) {
                                lastScore = Integer.parseInt(parts[i + 1]);
                            }
                        }
                    }
                    if (line.startsWith("bestmove")) {
                        break;
                    }
                }
            }
        } catch (IOException e) {
            log.error("Erreur lors de l'evaluation Stockfish", e);
        } finally {
            if (process != null) {
                process.destroy();
            }
        }
        return lastScore;
    }

    private void send(Writer writer, String command) throws IOException {
        writer.write(command + "\n");
        writer.flush();
    }

    private void waitFor(BufferedReader reader, String token) throws IOException {
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.contains(token)) {
                return;
            }
        }
    }

    @PreDestroy
    public void cleanup() {
        log.info("Arret du service Stockfish");
    }
}
