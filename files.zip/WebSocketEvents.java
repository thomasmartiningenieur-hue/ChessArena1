package com.chessarena.websocket;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Enveloppe generique des evenements WebSocket echanges entre client et serveur.
 */
public class WebSocketEvents {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MoveEvent {
        private Long gameId;
        private String uci;
        private String username;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class GameUpdateEvent {
        private Long gameId;
        private String fen;
        private String status;
        private String result;
        private String lastMoveSan;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ChatEvent {
        private Long gameId;
        private String username;
        private String message;
    }
}
