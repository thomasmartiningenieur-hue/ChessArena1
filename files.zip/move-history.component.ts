import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface HistoryEntry {
  moveNumber: number;
  san: string;
}

@Component({
  selector: 'app-move-history',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="history">
      <h3>Historique des coups</h3>
      <ol>
        @for (entry of moves; track entry.moveNumber) {
          <li>{{ entry.san }}</li>
        }
      </ol>
    </div>
  `,
  styles: [`
    .history { background: #16161f; padding: 1rem; border-radius: 8px; min-width: 180px; }
    ol { padding-left: 1.2rem; }
  `]
})
export class MoveHistoryComponent {
  @Input() moves: HistoryEntry[] = [];
}
