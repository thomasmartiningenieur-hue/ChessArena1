import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Chess, Square } from 'chess.js';

@Component({
  selector: 'app-chess-board',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="board">
      @for (row of ranks; track row) {
        @for (col of files; track col) {
          <div
            class="square"
            [class.light]="isLight(col, row)"
            [class.selected]="selected === col + row"
            (click)="onSquareClick(col + row)">
            {{ pieceAt(col + row) }}
          </div>
        }
      }
    </div>
  `,
  styles: [`
    .board {
      display: grid;
      grid-template-columns: repeat(8, 48px);
      grid-template-rows: repeat(8, 48px);
      width: fit-content;
      border: 2px solid #333;
    }
    .square {
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.6rem;
      background-color: #6b4f3a;
      cursor: pointer;
      user-select: none;
    }
    .square.light { background-color: #e8d3ae; }
    .square.selected { outline: 3px solid #4caf50; outline-offset: -3px; }
  `]
})
export class ChessBoardComponent {
  @Input() set fen(value: string) {
    this.chess.load(value);
  }
  @Output() moveMade = new EventEmitter<string>();

  chess = new Chess();
  selected: string | null = null;

  files = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
  ranks = [8, 7, 6, 5, 4, 3, 2, 1];

  isLight(file: string, rank: number): boolean {
    const fileIndex = this.files.indexOf(file);
    return (fileIndex + rank) % 2 === 0;
  }

  pieceAt(square: string): string {
    const piece = this.chess.get(square as Square);
    if (!piece) return '';
    const symbols: Record<string, string> = {
      p: '♟', r: '♜', n: '♞', b: '♝', q: '♛', k: '♚'
    };
    const symbol = symbols[piece.type];
    return piece.color === 'w' ? symbol.toUpperCase() : symbol;
  }

  onSquareClick(square: string): void {
    if (!this.selected) {
      this.selected = square;
      return;
    }

    if (this.selected === square) {
      this.selected = null;
      return;
    }

    // Notation UCI : depart + arrivee (ex: e2e4)
    const uci = this.selected + square;
    this.moveMade.emit(uci);
    this.selected = null;
  }
}
