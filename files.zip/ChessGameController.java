package com.chessarena.controller;

import com.chessarena.dto.GameResponse;
import com.chessarena.dto.MoveRequest;
import com.chessarena.model.ChessGame;
import com.chessarena.service.ChessGameService;
import com.chessarena.service.StockfishService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/games")
@RequiredArgsConstructor
@Tag(name = "Parties", description = "Gestion des parties d'echecs")
public class ChessGameController {

    private final ChessGameService chessGameService;
    private final StockfishService stockfishService;

    @GetMapping("/{id}")
    public ResponseEntity<GameResponse> getGame(@PathVariable Long id) {
        ChessGame game = chessGameService.getById(id);
        return ResponseEntity.ok(GameResponse.fromEntity(game));
    }

    @PostMapping("/{id}/moves")
    public ResponseEntity<GameResponse> playMove(@PathVariable Long id, @Valid @RequestBody MoveRequest request) {
        ChessGame game = chessGameService.playMove(id, request.getUci());
        return ResponseEntity.ok(GameResponse.fromEntity(game));
    }

    @PostMapping("/{id}/abandon")
    public ResponseEntity<Void> abandon(@PathVariable Long id) {
        chessGameService.abandonGame(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/best-move")
    public ResponseEntity<String> getBestMove(@PathVariable Long id,
                                               @RequestParam(required = false) Integer depth) {
        ChessGame game = chessGameService.getById(id);
        String bestMove = stockfishService.getBestMove(game.getFen(), depth);
        return ResponseEntity.ok(bestMove);
    }

    @GetMapping("/{id}/evaluation")
    public ResponseEntity<Integer> getEvaluation(@PathVariable Long id,
                                                  @RequestParam(required = false) Integer depth) {
        ChessGame game = chessGameService.getById(id);
        Integer score = stockfishService.evaluatePosition(game.getFen(), depth);
        return ResponseEntity.ok(score);
    }
}
