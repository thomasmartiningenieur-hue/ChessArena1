package com.chessarena.service;

import com.chessarena.dto.JwtResponse;
import com.chessarena.dto.LoginRequest;
import com.chessarena.dto.RegisterRequest;
import com.chessarena.model.Player;
import com.chessarena.repository.PlayerRepository;
import com.chessarena.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final PlayerRepository playerRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;

    @Transactional
    public JwtResponse register(RegisterRequest request) {
        if (playerRepository.existsByUsername(request.getUsername())) {
            throw new IllegalArgumentException("Ce nom d'utilisateur est deja pris");
        }
        if (playerRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("Cet email est deja utilise");
        }

        Player player = Player.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .build();

        playerRepository.save(player);

        String token = jwtUtil.generateToken(player.getUsername());
        return JwtResponse.builder()
                .token(token)
                .playerId(player.getId())
                .username(player.getUsername())
                .build();
    }

    public JwtResponse login(LoginRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );

        Player player = playerRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new IllegalArgumentException("Identifiants invalides"));

        String token = jwtUtil.generateToken(player.getUsername());
        return JwtResponse.builder()
                .token(token)
                .playerId(player.getId())
                .username(player.getUsername())
                .build();
    }
}
