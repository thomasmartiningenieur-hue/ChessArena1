package com.chessarena.exception;

public class GameNotFoundException extends RuntimeException {
    public GameNotFoundException(Long id) {
        super("Partie introuvable avec l'id : " + id);
    }
}
