package com.chessarena.exception;

public class PlayerNotFoundException extends RuntimeException {
    public PlayerNotFoundException(String identifier) {
        super("Joueur introuvable : " + identifier);
    }

    public PlayerNotFoundException(Long id) {
        super("Joueur introuvable avec l'id : " + id);
    }
}
