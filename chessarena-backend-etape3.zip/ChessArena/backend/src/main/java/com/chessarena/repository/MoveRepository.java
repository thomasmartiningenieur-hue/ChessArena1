package com.chessarena.repository;

import com.chessarena.model.Move;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MoveRepository extends JpaRepository<Move, Long> {

    List<Move> findByGame_IdOrderByMoveNumberAsc(Long gameId);
}
