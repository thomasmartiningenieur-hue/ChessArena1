package com.chessarena.repository;

import com.chessarena.model.ChessGame;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChessGameRepository extends JpaRepository<ChessGame, Long> {

    List<ChessGame> findByStatus(ChessGame.GameStatus status);

    List<ChessGame> findByWhitePlayer_IdOrBlackPlayer_Id(Long whitePlayerId, Long blackPlayerId);
}
