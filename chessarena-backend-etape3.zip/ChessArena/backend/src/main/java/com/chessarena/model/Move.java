package com.chessarena.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Entity
@Table(name = "moves", indexes = {
        @Index(name = "idx_move_game_id", columnList = "game_id"),
        @Index(name = "idx_move_game_number", columnList = "game_id, moveNumber")
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Move {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "game_id", nullable = false)
    private ChessGame game;

    @Column(nullable = false)
    private Integer moveNumber;

    // Notation UCI, ex: "e2e4"
    @Column(nullable = false, length = 10)
    private String uci;

    // Notation algébrique, ex: "Nf3"
    @Column(length = 10)
    private String san;

    @Column(nullable = false, length = 200)
    private String fenAfter;

    @Builder.Default
    @Column(nullable = false)
    private Instant playedAt = Instant.now();
}
