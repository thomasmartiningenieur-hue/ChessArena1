package com.chessarena.service;

import com.chessarena.dto.AuthResponse;
import com.chessarena.dto.LoginRequest;
import com.chessarena.dto.RegisterRequest;
import com.chessarena.model.Player;
import com.chessarena.repository.PlayerRepository;
import com.chessarena.security.CustomUserDetailsService;
import com.chessarena.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final PlayerRepository playerRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;
    private final CustomUserDetailsService userDetailsService;

    public AuthResponse register(RegisterRequest request) {
        if (playerRepository.existsByUsername(request.getUsername())) {
            throw new IllegalArgumentException("Ce nom d'utilisateur est déjà pris");
        }
        if (playerRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("Cet email est déjà utilisé");
        }

        Player player = Player.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .build();

        playerRepository.save(player);

        UserDetails userDetails = userDetailsService.loadUserByUsername(player.getUsername());
        String token = jwtUtil.generateToken(userDetails);

        return AuthResponse.builder()
                .token(token)
                .playerId(player.getId())
                .username(player.getUsername())
                .build();
    }

    public AuthResponse login(LoginRequest request) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
            );
        } catch (BadCredentialsException e) {
            throw new BadCredentialsException("Nom d'utilisateur ou mot de passe incorrect");
        }

        Player player = playerRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new BadCredentialsException("Nom d'utilisateur ou mot de passe incorrect"));

        UserDetails userDetails = userDetailsService.loadUserByUsername(player.getUsername());
        String token = jwtUtil.generateToken(userDetails);

        return AuthResponse.builder()
                .token(token)
                .playerId(player.getId())
                .username(player.getUsername())
                .build();
    }
}
