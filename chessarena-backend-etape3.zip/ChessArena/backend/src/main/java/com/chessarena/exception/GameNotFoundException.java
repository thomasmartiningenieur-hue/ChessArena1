package com.chessarena.exception;

public class GameNotFoundException extends RuntimeException {
    public GameNotFoundException(Long gameId) {
        super("Partie introuvable avec l'id : " + gameId);
    }
}
